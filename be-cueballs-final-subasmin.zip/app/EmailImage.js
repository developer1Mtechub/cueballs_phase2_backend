const imageURL = 'https://res.cloudinary.com/dlm56y4v4/image/upload/v1706182672/IMG-20231213-WA0004_2_1_jkflvc.png';

module.exports =  imageURL;
